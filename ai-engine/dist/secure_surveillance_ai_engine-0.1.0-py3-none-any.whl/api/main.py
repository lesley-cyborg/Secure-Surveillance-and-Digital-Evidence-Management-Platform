from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI
from fastapi.responses import RedirectResponse

from api.errors import register_exception_handlers
from api.router import router
from config.settings import Settings, get_settings
from detection.frame_decoder import FrameDecoder
from detection.frame_processor import FrameProcessor
from detection.inference_gate import InferenceGate
from detection.model_registry import ModelRegistry
from models.factory import create_production_detector
from models.lifecycle import ModelLifecycleManager

logger = structlog.get_logger(__name__)


def create_app(
    *,
    settings: Settings | None = None,
    registry: ModelRegistry | None = None,
    lifecycle: ModelLifecycleManager | None = None,
) -> FastAPI:
    resolved_settings = settings or get_settings()
    resolved_registry = registry or ModelRegistry()

    resolved_lifecycle = lifecycle or ModelLifecycleManager(
        enabled=resolved_settings.production_model_enabled,
        registry=resolved_registry,
        detector_factory=lambda: create_production_detector(resolved_settings),
        warmup_runs=resolved_settings.model_warmup_runs,
    )

    decoder = FrameDecoder(
        maximum_bytes=resolved_settings.maximum_upload_bytes,
        maximum_width=resolved_settings.maximum_image_width,
        maximum_height=resolved_settings.maximum_image_height,
        maximum_pixels=resolved_settings.maximum_image_pixels,
    )

    inference_gate = InferenceGate(
        maximum_concurrent=(resolved_settings.maximum_concurrent_inferences),
        queue_timeout_seconds=(resolved_settings.inference_queue_timeout_seconds),
    )

    processor = FrameProcessor(
        registry=resolved_registry,
        decoder=decoder,
        inference_gate=inference_gate,
    )

    @asynccontextmanager
    async def lifespan(
        _: FastAPI,
    ) -> AsyncIterator[None]:
        logger.info("application_startup_started")

        try:
            await resolved_lifecycle.startup()
        except Exception:
            logger.exception("application_startup_failed")
            raise

        logger.info(
            "application_startup_finished",
            lifecycle_state=resolved_lifecycle.state.value,
        )

        try:
            yield
        finally:
            logger.info(
                "application_shutdown_started",
                lifecycle_state=resolved_lifecycle.state.value,
            )

            try:
                await resolved_lifecycle.shutdown()
            except Exception:
                logger.exception(
                    "application_shutdown_failed",
                    lifecycle_state=resolved_lifecycle.state.value,
                    lifecycle_error=resolved_lifecycle.last_error,
                )
                raise
            finally:
                logger.info(
                    "application_shutdown_finished",
                    lifecycle_state=resolved_lifecycle.state.value,
                    lifecycle_error=resolved_lifecycle.last_error,
                )

    application = FastAPI(
        title="Secure Surveillance AI Engine",
        description=(
            "Model-independent detection service for surveillance image processing."
        ),
        version=resolved_settings.service_version,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        lifespan=lifespan,
    )

    application.state.settings = resolved_settings
    application.state.model_registry = resolved_registry
    application.state.frame_processor = processor
    application.state.model_lifecycle = resolved_lifecycle
    application.state.inference_gate = inference_gate

    @application.get(
        "/",
        include_in_schema=False,
    )
    async def root() -> RedirectResponse:
        return RedirectResponse(
            url="/docs",
            status_code=307,
        )

    application.include_router(router)
    register_exception_handlers(application)

    return application


app = create_app()
