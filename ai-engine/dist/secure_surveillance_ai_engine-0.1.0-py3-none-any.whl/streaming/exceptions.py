from __future__ import annotations


class StreamingError(RuntimeError):
    """Base exception for camera streaming failures."""


class FrameQueueError(StreamingError):
    """Base exception for frame queue failures."""


class FrameQueueClosedError(FrameQueueError):
    """Raised when operating on a closed frame queue."""


class FrameQueueTimeoutError(FrameQueueError):
    """Raised when no frame arrives before the timeout."""
